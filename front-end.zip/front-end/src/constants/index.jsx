export const ACCESS_TOKEN = "accessToken";

const urls = {
  dev: "http://localhost:8080",
  test: "http://34.66.230.240",
  prod: "https://legalissolucoes.com.br",
};

// const chaveReCaptcha = {
//   dev: "6LfkWvoUAAAAAK2g1f-5_4CFfAh4P_9nMkegQqqJ",
//   test: "6LfkWvoUAAAAAK2g1f-5_4CFfAh4P_9nMkegQqqJ",
//   prod: "6LdV8ZsaAAAAAO8sLiX2Y_I-MdR7kuDDg_wylHV-",
// }

export const API_BASE_URL = urls[process.env.REACT_APP_STAGE]
  ? urls[process.env.REACT_APP_STAGE]
  : "http://localhost:8080";

// export const API_BASE_URL_IMAGE = API_BASE_URL + "/publico/foto/";

// export const CHAVE_RECAPTCHA = chaveReCaptcha[process.env.REACT_APP_STAGE] ? chaveReCaptcha[process.env.REACT_APP_STAGE] : chaveReCaptcha.dev;
