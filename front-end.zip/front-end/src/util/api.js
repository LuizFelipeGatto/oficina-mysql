import axios from "axios";
// import * as jwtDecode from "jwt-decode";
import { API_BASE_URL, ACCESS_TOKEN } from "../constants";

export const getToken = () => localStorage.getItem(ACCESS_TOKEN);

const api = () => {
  const api1 = axios.create({
    baseURL: API_BASE_URL,
    headers: {
      "content-type": "application/json",
    },
  });
  // Add a request interceptor
  api1.interceptors.request.use(
    (config) => {
      const token = getToken();

      if (token != null) {
        config.headers.Authorization = `Bearer ${token}`;
      }

      return config;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  // Add a response interceptor
  api1.interceptors.response.use(
    (response) => {
      // Any status code that lie within the range of 2xx cause this function to trigger
      return response.data;
    },
    (error) => {
      return Promise.reject(error);
    }
  );

  return api1;
};

export function getDados() {
  return api().get(`/sensores`);
}
