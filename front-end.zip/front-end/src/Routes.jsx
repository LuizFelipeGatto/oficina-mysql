import React, { useState } from "react";
// import Alert from "react-s-alert";
// import AppHeader from "./componentes/AppHeader";
// import PrivateRoute from "./componentes/PrivateRoute";
import { Route, Switch, Router } from "react-router-dom";
import { createHashHistory } from "history";
// import Loader from "react-loader-spinner";

// import { getCurrentUser } from "./util/Api";
// import { ACCESS_TOKEN } from "./constantes";

import AppHeader from "./componentes/AppHeader";
import Dashboard from "./paginas/dashboard";
import Home from "./paginas/home";
import CadastroFazenda from "./paginas/cadastro";
// import "react-s-alert/dist/s-alert-default.css";
// import "react-s-alert/dist/s-alert-css-effects/slide.css";
// import "react-loader-spinner/dist/loader/css/react-spinner-loader.css";
import "./App.css";

const history = createHashHistory();

// const rotasAdm = [
//   "/dashboard",
//   "/planos",
//   "/conteudos",
//   "/usuarios",
//   "/comentarios",
//   "/cadastroRol",
//   "/cadastroOtimize",
//   "/secaoRol",
//   "/cadastroTexto",
// ];

const Routes = () => {
  // const [currentUser, setCurrentUser] = useState(null);
  // const [authenticated, setAuthenticated] = useState(false);
  const [loading, setLoading] = useState(false);
  // const [apareceRodape, setApareceRodape] = useState(true);

  // const loadCurrentlyLoggedInUser = () => {
  //   setLoading(true);

  //   getCurrentUser()
  //     .then((data) => {
  //       setAuthenticated(true);
  //       setCurrentUser(data);
  //       setLoading(false);
  //       history.push("/modulos");
  //     })
  //     .catch((error) => {
  //       localStorage.removeItem(ACCESS_TOKEN);
  //       setLoading(false);
  //     });
  // };

  // const handleLogout = () => {
  //   localStorage.removeItem(ACCESS_TOKEN);
  //   setAuthenticated(false);
  //   setCurrentUser(null);
  //   Alert.success("Logout efetuado com sucesso!");
  // };

  // useEffect(() => {
  //   loadCurrentlyLoggedInUser();
  // }, []);

  // useEffect(() => {
  //   if (
  //     rotasAdm.includes(history.location.pathname) &&
  //     (!currentUser || currentUser.nivel === "CLIENTE")
  //   ) {
  //     if (!currentUser) {
  //       history.push("/login");
  //     }
  //     history.push("/modulos");
  //   }
  //   // eslint-disable-next-line
  // }, [history.location.pathname]);

  return (
    <Router history={history}>
      {loading ? (
        <div className="loading">
          {/* <Loader
            type="BallTriangle"
            color="#00BFFF"
            height={200}
            width={200}
          /> */}
        </div>
      ) : null}
      <AppHeader
        // currentUser={currentUser}
        // authenticated={authenticated}
        // onLogout={handleLogout}
        history={history}
      />
      <Switch>
        <Route
          exact
          path="/dashboard"
          render={(props) => <Dashboard setLoading={setLoading} />}
        />
        <Route
          exact
          path="/"
          render={(props) => <Home setLoading={setLoading} />}
        ></Route>
        <Route
          exact
          path="/home"
          render={(props) => <Home setLoading={setLoading} />}
        ></Route>
        <Route
          exact
          path="/cadastroFazenda"
          render={(props) => <CadastroFazenda setLoading={setLoading} />}
        ></Route>
        {/* 
        <Route
          exact
          path="/signup"
          render={(props) => (
            <Signup
              setLoading={setLoading}
              authenticated={authenticated}
              {...props}
            />
          )}
        />
        <Route
          path="/redefinirSenha/:hash"
          exact
          render={(props) => (
            <RedefinirSenha setLoading={setLoading} {...props} />
          )}
        />
        <Route
          path="/blog"
          exact
          render={(props) => (
            <Blog setLoading={setLoading} {...props} tipo="BLOG" />
          )}
        />
        <Route
          path="/quemSomos"
          exact
          render={(props) => (
            <QuemSomos setLoading={setLoading} {...props} tipo="QuemSomos" />
          )}
        />
        <Route
          path="/todosComentarios"
          exact
          render={() => (
            <TodosComentarios setLoading={setLoading} tipo="TodosComentarios" />
          )}
        />
        <Route
          path="/podcasts"
          exact
          render={(props) => <Podcast setLoading={setLoading} {...props} />}
        />
        <Route
          path="/palestras"
          exact
          render={(props) => (
            <Palestras setLoading={setLoading} {...props} tipo="Palestras" />
          )}
        />
        <Route
          path="/noticias"
          exact
          render={(props) => (
            <Noticias setLoading={setLoading} {...props} tipo="Noticias" />
          )}
        />
        <Route
          path="/artigos"
          exact
          render={(props) => (
            <Artigos setLoading={setLoading} {...props} tipo="Artigos" />
          )}
        />
        <Route
          path="/confirmarEmail/:hash"
          exact
          render={(props) => (
            <ConfirmarEmail setLoading={setLoading} {...props} />
          )}
        />
        <Route
          exact
          path="/contato"
          render={(props) => <Contato setLoading={setLoading} {...props} />}
        />
        <Route
          exact
          path="/login"
          render={(props) => (
            <Login
              setLoading={setLoading}
              loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
              authenticated={authenticated}
              {...props}
            />
          )}
        />
        <Route
          path="/blog/:id"
          exact
          render={(props) => (
            <Pagina
              goBack="/blog"
              setLoading={setLoading}
              {...props}
              tipo="BLOG"
            />
          )}
        /> */}
        {/* <PrivateRoute
          exact
          path="/modulos"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Modulos}
        />
        <PrivateRoute
          exact
          path="/alterarSenha"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={AlteraSenha}
        />
        <PrivateRoute
          exact
          path="/comentarios"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Comentarios}
        />
        <PrivateRoute
          exact
          path="/cadastroRol"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={OtimizeCadastroRol}
        />
        <PrivateRoute
          exact
          path="/cadastroOtimize"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={OtimizeCadastros}
        />
        <PrivateRoute
          exact
          path="/secaoRol"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={OtimizeCadastroSecao}
        />
        <PrivateRoute
          exact
          path="/cadastroTexto"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={OtimizeCadastroTexto}
        />
        <PrivateRoute
          exact
          path="/profile"
          authenticated={authenticated}
          loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Perfil}
        />
        <PrivateRoute
          exact
          path="/pagamentos"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Pagamentos}
        />
        <PrivateRoute
          exact
          path="/contratar"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Contratar}
          loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
        />
        <PrivateRoute
          exact
          path="/contratar/:id"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Contratar}
          loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
        />
        <PrivateRoute
          exact
          path="/cadastros"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Cadastros}
        />
        <PrivateRoute
          exact
          path="/planos"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Planos}
        />
        <PrivateRoute
          exact
          path="/usuarios"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Usuarios}
        />
        <PrivateRoute
          exact
          path="/consultorias"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Consultorias}
        />
        <PrivateRoute
          exact
          path="/dashboard"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Dashboard}
        />
        <PrivateRoute
          exact
          path="/consultoria"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Consultoria}
          loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
        />
        <PrivateRoute
          exact
          path="/consultoria/:id"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Consultoria}
          loadCurrentlyLoggedInUser={loadCurrentlyLoggedInUser}
        />
        <PrivateRoute
          exact
          path="/conteudos"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Conteudos}
        />
        <PrivateRoute
          exact
          path="/conteudo"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Conteudo}
        />
        <PrivateRoute
          exact
          path="/conteudo/:id"
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={Conteudo}
        />
        <PrivateRoute
          path="/site/blog"
          exact
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={CadastroPagina}
        />
        <PrivateRoute
          path="/site/blog/nova"
          exact
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={CadastroPaginaNova}
        />
        <PrivateRoute
          path="/site/blog/editar/:id"
          exact
          authenticated={authenticated}
          setLoading={setLoading}
          currentUser={currentUser}
          component={CadastroPaginaNova}
        /> */}
      </Switch>
      {/* <Alert
        stack={{ limit: 3 }}
        timeout={3000}
        position="top-right"
        effect="slide"
        offset={65}
      /> */}
    </Router>
  );
};

export default Routes;
