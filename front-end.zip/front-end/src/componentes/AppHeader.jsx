import React from "react";
// import { Modal, Button } from "react-bootstrap";
import logoOficina from "../imagens/logo.png";
import { Navbar, Nav, NavDropdown } from "react-bootstrap";
// import Notificacao from "./Notificacao";
// import { Link } from "react-router-dom";
// import "./header.css";

const AppHeader = (props) => {
  // const [ativo, setAtivo] = useState(false);
  // const handleClose = () => setAtivo(false);
  return (
    <Navbar
      id="navH"
      bg="white"
      expand="lg"
      className="box-shadow no-radius robotR"
    >
      {/* <Modal
        id="modCome"
        show={ativo}
        onHide={() => setAtivo(false)}
        size="xl"
        className="robotM"
      >
        <Modal.Header>
          <Modal.Title>Entre em contato!</Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-justify">
          <h5 className="robotR">
            Entre em contato e contrate palestras e cursos.
          </h5>
        </Modal.Body>
        <Modal.Footer>
          <Button onClick={handleClose} className="btn btn-success btn-lg">
            <Link to="/contato" className="text-light">
              Entrar em contato
            </Link>
          </Button>
          <Button className="btn btn-info btn-lg" onClick={handleClose}>
            Fechar
          </Button>
        </Modal.Footer>
      </Modal> */}
      <Navbar.Brand href="#/" className="">
        <img
          className="image-logo pl-md-2"
          src={logoOficina ? logoOficina : null}
          alt="logo Legalis"
        />
      </Navbar.Brand>
      <Navbar.Toggle aria-controls="basic-navbar-nav" />
      <Navbar.Collapse id="basic-navbar-nav">
        <Nav className="ml-5">
          <Nav.Link href="/#/" className="links m-2">
            Home
          </Nav.Link>
          <Nav.Link href="#/dashboard" className="links m-2">
            Dashboard
          </Nav.Link>
          <Nav id="na2" className="mx-auto text-center m-2">
            <NavDropdown
              title="Ações"
              className="links"
              id="basic-nav-dropdown"
            >
              <NavDropdown.Item href="#/cadastroFazenda">
                <i className="icones-header fa fa-home"></i> Cadastro de Fazenda
              </NavDropdown.Item>
              <NavDropdown.Item href="#/noticias">
                <i className="icones-header fa fa-home"></i> Ver fazendas
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
          <Nav.Link href="#/" className="links m-2">
            Contato
          </Nav.Link>
          {/* <Nav.Link href="#/blog" className="links m-2">
            Blog
          </Nav.Link> */}
          {/* <div className="socaisflex d-flex">
            <Nav.Link
              href="https://www.instagram.com/legalis.solucoes/"
              target="_blank"
              className="navSocial links m-2"
            >
              <span className="fa fa-instagram"></span>
            </Nav.Link>

            <Nav.Link
              href="https://www.facebook.com/legalis.solucoes/"
              target="_blank"
              className="navSocial links m-2"
            >
              <span className="fa fa-facebook"></span>
            </Nav.Link>
          </div> */}
          {/* <Nav.Link className="navSocial mt-2 mb-2 ml-3">
            <Notificacao usuario={props.currentUser} />
          </Nav.Link> */}
        </Nav>
        {/* <Nav className="mx-auto text-center">
          {!props.authenticated && !props.currentUser ? (
            <>
              <Nav.Link href="#/login" className="links2">
                Login/Cadastre-se
              </Nav.Link>
            </>
          ) : (
            <NavDropdown
              className="linkNome"
              title={
                props.currentUser ? props.currentUser.nome.split(" ")[0] : ""
              }
              id="basic-nav-dropdown"
            >
              <NavDropdown.Item href="#/modulos">
                <i className="icones-header fa fa-home fa-fw"></i> Módulos
              </NavDropdown.Item>
              <NavDropdown.Item href="#/profile">
                <i className="icones-header fa fa-user fa-fw"></i> Dados
              </NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item onClick={props.onLogout}>
                <i
                  className="icones-header fa fa-sign-out fa-fw"
                  aria-hidden="true"
                ></i>
                Sair
              </NavDropdown.Item>
            </NavDropdown>
          )}
        </Nav> */}
      </Navbar.Collapse>
    </Navbar>
  );
};

export default AppHeader;
