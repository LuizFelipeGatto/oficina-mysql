import React, { useState } from "react";
import * as moment from "moment";
import "moment/locale/pt-br";
import ReactPaginate from "react-paginate";
import { Link } from "react-router-dom";
import { confirmAlert } from "react-confirm-alert"; // Import
import "react-confirm-alert/src/react-confirm-alert.css"; // Import css
import { Modal, Button } from "react-bootstrap";

const Listagem = (props) => {
  const [ativarText, setAtivarText] = useState(false);
  const [textoVer, setTextoVer] = useState("");
  const [subtituloVer, setSubtituloVer] = useState("");
  const handleClose = () => setAtivarText(false);
  moment.locale("pt-BR");
  // const atualizar = () => props.history.push("/comentarios");

  const {
    data,
    nome,
    tipo,
    acao,
    goToEdit,
    botaoEditar,
    botaoExcluir,
    botaoAtivar,
    // funcaoAtivar,
    paginacao,
    recarregar,
    login,
    cpfCNPJ,
    titulo,
    novoLancamento,
    linkNovoLancamento,
    labelLink,
    filtroAvancado,
    filtroSimples,
    buscaSimplificada,
    labelFiltroSimples,
    abrirModalPesquisa,
    visualizar,
    via,
    email,
    telefone,
    tipoDeProcedimento,
    descricao,
    valor,
    dataPedido,
    gerarOrdemServico,
    custonConfirmTitulo,
    custonConfirmLabel,
    custonConfirmFunction,
    //cliente,
    dataDaEntrega,
    clientePedido,
    botaoExcluirDropdown,
    dataEntrega,
    modalPagamento,
    nomeOrdemServico,
    statusPagamento,
    status,
    ativo,
    tituloPlano,
    currentUser,
    tituloConsultoria,
    tituloPagina,
    subtitulo,
    verTexto,
    decreto,
    rol,
    secao,
    parcela,
    notVisualize,
  } = props;



  const ativar = (item) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="container-fluid box-shadow pt-3 pb-3 box-confirmation">
            <div className="row justify-content-around">
              <div className="col-12 text-center">
                <h3>
                  {item.ativo === true ? "Retirar " : "Ativar "}
                  comentário!
                </h3>
                <p>
                  Deseja {item.ativo === true ? "retirar " : "ativar "} o
                  comentário do usuário {item.nome}?
                </p>
              </div>
              <div className="row text-center">
                <div className="col-md-6">
                  <button className="btn btn-outline-warning" onClick={onClose}>
                    Não
                  </button>
                </div>

                <div className="col-md-6">
                </div>
              </div>
            </div>
          </div>
        );
      },
    });
  };

  const exluir = (item) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="container-fluid box-shadow pt-3 pb-3 box-confirmation">
            <div className="row justify-content-around">
              <div className="col-12 text-center">
                <h3>Confirma exclusão?</h3>
                <p>
                  Após a exclusão não sera possivel recuperar, deseja continuar?
                </p>
              </div>
              <div className="col-12 text-center">
                <button
                  className="btn btn-warning btn-lg m-2"
                  onClick={onClose}
                >
                  Não
                </button>

                <button
                  className="btn btn-outline-success btn-lg m-2"
                  onClick={() => {
                    botaoExcluir
                      ? botaoExcluir(item)
                      : botaoExcluirDropdown(item);
                    onClose();
                  }}
                >
                  Sim
                </button>
              </div>
            </div>
          </div>
        );
      },
    });
  };

  const custonConfirm = (item) => {
    confirmAlert({
      customUI: ({ onClose }) => {
        return (
          <div className="container-fluid box-shadow p-4 box-confirmation">
            <div className="justify-content-center robotR">
              <div className="col-12 text-center">
                <h4>{custonConfirmTitulo}</h4>
                <h5>{custonConfirmLabel}</h5>
              </div>
              <div className="col-12 text-center">
                <button
                  className="btn btn-warning btn-lg m-2"
                  onClick={onClose}
                >
                  Não, quero cancelar!
                </button>
                <button
                  className="btn btn-outline-success btn-lg m-2"
                  onClick={() => {
                    custonConfirmFunction(item);
                    onClose();
                  }}
                >
                  Sim, desejo continuar!
                </button>
              </div>
            </div>
          </div>
        );
      },
    });
  };

  function verDesc(item) {
    setTextoVer(item.descricao);
    setSubtituloVer(item.subtitulo);
    setAtivarText(true);
  }

  const onPageChange = ({ selected }) => {
    paginacao.changePage(selected);
  };

  return (
    <div className="container  pb-2">
      <Modal
        id="modCome"
        show={ativarText}
        onHide={() => setAtivarText(false)}
        size="xl"
      >
        <Modal.Header closeButton>
          <Modal.Title>Texto do título: {subtituloVer}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <p>{textoVer}</p>
        </Modal.Body>
        <Modal.Footer>
          <Button className="btn btn-primary" onClick={handleClose}>
            <span className="fa fa-times"></span> Fechar
          </Button>
        </Modal.Footer>
      </Modal>
      <div className="row box-shadow mb-3">
        <div className="col-12 pt-3">
          <div
            style={{
              display: "flex",
              flexDirection: "row",
              alignItems: "center",
              justifyContent: "space-between",
            }}
          >
            <div>
              {titulo}
              {filtroAvancado && (
                <div style={{ marginLeft: 5 }}>
                  <button
                    className="btn btn-info btn-sm mb-1"
                    onClick={abrirModalPesquisa}
                  >
                    <i className="fa fa-search-plus" /> Pesquisa avançada
                  </button>
                </div>
              )}
            </div>

            {novoLancamento || (paginacao && paginacao.changePage) ? (
              <div
                style={{
                  display: "flex",
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-end",
                }}
              >
                <div
                  style={{
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    marginLeft: 10,
                  }}
                >
                  {novoLancamento && currentUser.nivel === "CLIENTE" ? (
                    <div>
                      <Link
                        className="btn btn-warning my-1"
                        to={linkNovoLancamento}
                      >
                        <i className="fa fa-plus" /> {labelLink}
                      </Link>
                    </div>
                  ) : null}
                  {novoLancamento && currentUser.nivel === "ADM" ? (
                    <div>
                      <Link to={linkNovoLancamento}>
                        <i className="fa fa-plus" /> {labelLink}
                      </Link>
                    </div>
                  ) : null}
                  {paginacao.changePage && (
                    <div className="mb-1">
                      <span
                        className="visulizar-checklist ho btn btn-info"
                        onClick={() => paginacao.changePage(paginacao.number)}
                      >
                        <i className="fa fa-refresh" /> Atualizar Listagem
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ) : undefined}
          </div>
          {filtroSimples && (
            <div>
              <input
                style={{ width: "100%", marginBottom: 5 }}
                placeholder={labelFiltroSimples}
                className="form-control "
                onChange={(e) => buscaSimplificada(e.target.value)}
              />
            </div>
          )}
          <div className="table-responsive-md">
            <table className="table table-hover table-sm table-bordered table-striped">
              <thead className="thead-light">
                <tr>
                  {data || dataPedido ? <th scope="col">Data</th> : null}
                  {nome ? <th scope="col">Nome</th> : null}
                  {tituloPlano ? <th scope="col">Título</th> : null}

                  {currentUser?.nivel === "ADM" ? (
                    <th scope="col">Cliente</th>
                  ) : null}
                  {dataDaEntrega ? <th scope="col">Data da entrega</th> : null}
                  {clientePedido ? <th scope="col">Cliente</th> : null}
                  {tipo ? <th scope="col">Tipo</th> : null}
                  {dataEntrega ? <th scope="col">Data entrega</th> : null}
                  {email ? <th scope="col">Email</th> : null}
                  {subtitulo ? <th scope="col">Subtítulo</th> : null}
                  {decreto ? <th scope="col">Decreto</th> : null}
                  {rol ? <th scope="col">Rol</th> : null}
                  {secao ? <th scope="col">Seção</th> : null}
                  {descricao ? <th scope="col">Descrição</th> : null}
                  {verTexto ? <th scope="col">Ver Texto</th> : null}
                  {telefone ? <th scope="col">Telefone</th> : null}
                  {ativo ? <th scope="col">Status</th> : null}
                  {via ? <th scope="col">Via de aplicação</th> : null}
                  {cpfCNPJ ? <th scope="col">CPF/CNPJ</th> : null}
                  {statusPagamento ? <th scope="col">status</th> : null}
                  {tituloPagina ? <th scope="col">Titulo</th> : null}
                  {valor ? <th scope="col">Valor</th> : null}
                  {parcela ? <th scope="col">Parcelas</th> : null}
                  {/* {ativo ? <th scope="col">Situação</th> : null} */}
                  {status ? <th scope="col">Status</th> : null}
                  {botaoAtivar ? <th scope="col">Situação</th> : null}
                  {tituloConsultoria ? <th scope="col">Título</th> : null}
                  {tipoDeProcedimento ? (
                    <th scope="col">Tipo de Procedimento</th>
                  ) : null}
                  {acao ? <th scope="col">Ações</th> : null}
                  {login ? <th scope="col">Login</th> : null}
                  {botaoExcluir || recarregar || botaoEditar || visualizar ? (
                    <th scope="col">Ações</th>
                  ) : null}
                </tr>
              </thead>
              <tbody className="table-hover">
                {props.paginacao
                  ? props.paginacao.content.map((item) => {
                      return (
                        <tr
                          key={item.id}
                          className={`${
                            item.ativo === false ? "table-warning" : ""
                          }`}
                        >
                          {data ? (
                            <th scope="row">{moment(item.data).format("L")}</th>
                          ) : null}

                          {dataPedido ? (
                            <th scope="row">
                              {moment(item.dataPedido).format("L")}
                            </th>
                          ) : null}

                          {nome && item.nome ? <td>{item.nome}</td> : null}
                          {tituloPlano && item.titulo ? (
                            <td>{item.titulo}</td>
                          ) : null}

                          {email ? <td>{item.email}</td> : null}

                          {currentUser?.nivel === "ADM" ? (
                            <td>{item.cliente.nome}</td>
                          ) : null}

                          {clientePedido ? (
                            <td>{item.pedido.cliente.nome}</td>
                          ) : null}

                          {nomeOrdemServico ? (
                            <td>{item.ordemDeServico.pedido.cliente.nome}</td>
                          ) : null}

                          {dataDaEntrega ? (
                            <th scope="row">
                              {moment(item.dataDaEntrega).format("L")}
                            </th>
                          ) : null}

                          {dataEntrega ? (
                            <th scope="row">
                              {moment(item.pedido.dataDaEntrega).format("L")}
                            </th>
                          ) : null}

                          {tituloPagina ? <td>{item.titulo}</td> : null}

                          {telefone ? <td>{item.telefone}</td> : null}

                          {subtitulo ? <td>{item.subtitulo}</td> : null}

                          {decreto ? <td>{item.decreto}</td> : null}

                          {rol ? <td>{item?.rol?.titulo}</td> : null}

                          {secao ? <td>{item?.secao?.titulo}</td> : null}

                          {descricao && item.descricao ? (
                            <td>{item.descricao}</td>
                          ) : null}

                          {verTexto ? (
                            <td>
                              <button
                                type="button"
                                className="btn btn-warning mr-1"
                                onClick={(e) => verDesc(item)}
                              >
                                <i className="fa fa-eye"></i>
                              </button>
                            </td>
                          ) : null}

                          {ativo ? (
                            <td>{item.ativo === true ? "Ativo" : "Inativo"}</td>
                          ) : null}

                          {cpfCNPJ && item.cpfCNPJ ? (
                            <td>{item.cpfCNPJ}</td>
                          ) : null}

                          {login && item.login ? <td>{item.login}</td> : null}

                          {tipoDeProcedimento && item.tipoDeProcedimento ? (
                            <td>{item.tipoDeProcedimento}</td>
                          ) : null}

                          {statusPagamento ? (
                            <td>{item.statusPagamento}</td>
                          ) : null}

                          {valor ? (
                            <td>
                              {" "}
                              {item.valor
                                ? item.valor.toLocaleString("pt-br", {
                                    style: "currency",
                                    currency: "BRL",
                                  })
                                : "--"}
                            </td>
                          ) : null}

                          {parcela && <td>{item.parcela}</td>}

                          {status ? (
                            <td>{item.status ? "Aberta" : "Encerrada"}</td>
                          ) : null}
                          {tituloConsultoria ? <td>{item.titulo}</td> : null}
                          {botaoExcluir ||
                          botaoEditar ||
                          botaoAtivar ||
                          visualizar ? (
                            <td>
                              {botaoExcluir && !item.resposta ? (
                                <button
                                  type="button"
                                  className="btn btn-sm btn-danger mr-1"
                                  onClick={(e) => exluir(item)}
                                >
                                  <i className="fa fa-trash"></i>
                                </button>
                              ) : null}

                              {botaoAtivar ? (
                                <button
                                  type="button"
                                  className="btn btn-sm btAtivar mr-1"
                                  onClick={(e) => ativar(item)}
                                >
                                  <i
                                    className={`fa ${
                                      item.ativo
                                        ? "fa-toggle-on p-2"
                                        : "fa-toggle-off p-2"
                                    }`}
                                  ></i>
                                </button>
                              ) : null}

                              {botaoEditar ? (
                                <button
                                  type="button"
                                  className="btn btn-sm btn-info mr-1"
                                  onClick={(e) => {
                                    botaoEditar(item);
                                    window.scrollTo({
                                      top: 0,
                                      left: 0,
                                      behavior: "smooth",
                                    });
                                  }}
                                >
                                  <i className="fa fa-pencil"></i>
                                </button>
                              ) : null}

                              {visualizar ? (
                                <button
                                  type="button"
                                  className="btn btn-sm btn-info mr-1"
                                  rel="noopener noreferrer"
                                  onClick={(e) => props.setIten(item)}
                                >
                                  <i className={`fa fa-eye`}></i>
                                </button>
                              ) : null}
                            </td>
                          ) : null}
                          {acao ? (
                            <td>
                              <button
                                type="button"
                                className="btn btn-success btn-sm dropdown-toggle"
                                data-toggle="dropdown"
                                aria-haspopup="true"
                                aria-expanded="false"
                              >
                                Ação
                              </button>
                              <div className="dropdown-menu">
                                {!notVisualize && (
                                  <div
                                    className="dropdown-item"
                                    onClick={() => props.setIten(item)}
                                  >
                                    <i className="fa fa-eye" />
                                    <span className="ml-2">Visualizar</span>
                                  </div>
                                )}

                                {goToEdit ? (
                                  <Link
                                    to={`${goToEdit}${item.id}`}
                                    className="dropdown-item"
                                  >
                                    <i className="fa fa-pencil" />
                                    <span className="ml-2">Editar</span>
                                  </Link>
                                ) : null}

                                {gerarOrdemServico && !item.ordemServico ? (
                                  <div
                                    className="dropdown-item"
                                    onClick={() => custonConfirm(item)}
                                  >
                                    <i className="fa fa-pencil" />
                                    <span className="ml-2">
                                      Gerar Ordem de Serviço
                                    </span>
                                  </div>
                                ) : null}

                                {botaoExcluirDropdown &&
                                !item.ordemServico &&
                                item.status !== "FINALIZADA" ? (
                                  <div
                                    className="dropdown-item"
                                    onClick={() => exluir(item)}
                                  >
                                    <i className="fa fa-trash" />
                                    <span className="ml-2">Excluir</span>
                                  </div>
                                ) : null}

                                {custonConfirmFunction &&
                                currentUser.nivel === "ADM" &&
                                item.status ? (
                                  <div
                                    className="dropdown-item"
                                    onClick={() => custonConfirm(item)}
                                  >
                                    <i className="fa fa-check" />
                                    <span className="ml-2">Finalizar</span>
                                  </div>
                                ) : null}

                                {modalPagamento &&
                                item.status !== "FINALIZADA" ? (
                                  <div
                                    className="dropdown-item"
                                    onClick={() => modalPagamento(item)}
                                  >
                                    <i className="fa fa-external-link" />
                                    <span className="ml-2">Pagar</span>
                                  </div>
                                ) : null}
                              </div>
                            </td>
                          ) : null}
                        </tr>
                      );
                    })
                  : null}
              </tbody>
            </table>
            {props.lista && props.lista.length === 0 ? (
              <h6 className="text-center">Sem dados encontrados!</h6>
            ) : null}
            {paginacao && paginacao.totalPages > 1 ? (
              <ReactPaginate
                pageCount={paginacao.totalPages}
                pageRangeDisplayed={6}
                marginPagesDisplayed={5}
                previousLabel="Anterior"
                nextLabel="Próximo"
                breakClassName="li-border"
                containerClassName="d-flex no-li-decoration justify-content-around"
                pageClassName="li-border ml-1 mr-1"
                onPageChange={onPageChange}
                activeClassName="active-page"
                previousClassName="mr-3 link-page"
                nextClassName="ml-3 link-page"
                disabledClassName="disable-page"
              />
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Listagem;
