import React from "react";

const AppFooter = (props) => {
  return (
    <footer className="bg-primary text-light py-3">
      <h5>Desenvolvido pelo projeto 1</h5>
    </footer>
  );
};

export default AppFooter;
