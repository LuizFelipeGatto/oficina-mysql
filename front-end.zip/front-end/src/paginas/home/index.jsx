import React from "react";

const Home = (props) => {
  // const [planos, setPlanos] = useState([]);
  // const [ativo, setAtivo] = useState(false);

  // useEffect(() => {
  //   getPlanosPublico().then((planos) => {
  //     setPlanos(planos);
  //   });
  //   if (
  //     props.location &&
  //     props.location.state &&
  //     props.location.state.elemento
  //   ) {
  //     window.scrollTo({
  //       top:
  //         document.getElementById(props.location.state.elemento).offsetTop - 70,
  //       behavior: "smooth",
  //     });
  //   }
  // }, [props.location]);

  return (
    <section>
      <div className="container">
        <h2 className="mt-3">Sobre a Oficina 4.0</h2>
      </div>
    </section>
  );
};

export default Home;
