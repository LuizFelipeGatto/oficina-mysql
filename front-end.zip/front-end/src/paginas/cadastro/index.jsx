import React, { useState, useEffect, useRef } from "react";
import Alert from "react-s-alert";
import axios from "axios";
import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { Modal, Button } from "react-bootstrap";
// import GoBack from "../../componentes/goBack";
import FormGroup from "../../componentes/form-group";

const api = axios.create({
  baseURL: "http://localhost:8080",
});

const esquema = Yup.object().shape({
  nome: Yup.string().min(3, "Obrigatório").required("Obrigatório"),
  url: Yup.string()
    .required("Obrigatório").url("Digite uma URL válida"),
});

const Fazenda = (props) => {
  const [fazendas, setFazendas] = useState([]);
  const [atualiza, setAtualiza] = useState(false);
  const formikRef = useRef();
  const [classBtn, setClassBtn] = useState("btn-success");
  const [ativo, setAtivo] = useState(false);
  const handleClose = () => setAtivo(false);
  const [id, setId] = useState();
  const [nome, setNome] = useState();

  const findFazendas = () => {
    props.setLoading(true);
    api.get("/fazenda").then(({data}) => {
      setFazendas(data);
      props.setLoading(false);
    });
  };

  useEffect(() => {
    findFazendas();
    // eslint-disable-next-line
  }, []);

  const excluir = (id) => {
    api.delete(`/fazenda/${id}`)
    .then(() => {
      Alert.warning("Fazenda excluída com sucesso!");
        findFazendas();
    })
    .catch((error) => {
      Alert.error((error && error.message) || "deu ruim!");
    });
  };

  const editarFazenda = async (procedimento) => {
    await setAtualiza(true);
    setClassBtn("btn-info");
    formikRef.current.values.nome = procedimento.nome;
    formikRef.current.values.url = procedimento.url;
    formikRef.current.values.id = procedimento.id;
    await setAtualiza(false);
  };

  const salvar = (formulario) => {
    api
      .post("/fazenda", formulario)
      .then(() => {
        if (classBtn === "btn-success") {
          Alert.success("Fazenda cadastrada com sucesso!");
        } else {
          Alert.success("Fazenda alterada com sucesso!");
        }
        formulario.nome = "";
        formulario.url = "";
        formulario.id = null;
        setClassBtn("btn-success");
        findFazendas();
      })
      .catch((error) => {
        Alert.error((error && error.message) || "deu ruim!");
      });
  };

  return (
    <div className="container robotR">
      <Modal
        id="modCome"
        show={ativo}
        onHide={() => setAtivo(false)}
        size="xl"
      >
        <Modal.Header className="bg-warning">
          <Modal.Title className="text-center">
            Confirmar exclusão
          </Modal.Title>
        </Modal.Header>
        <Modal.Body className="text-center">
          Deseja mesmo excluir a fazenda {nome} ?
        </Modal.Body>
        <Modal.Footer className="mx-auto">
          <Button className="btn btn-primary btn-lg" onClick={handleClose}>
            Não
          </Button>
          <Button className="btn btn-danger btn-lg" onClick={(e) => excluir(id)}>
            Sim
          </Button>
        </Modal.Footer>
      </Modal>
      {/* <GoBack link={"/cadastros"} /> */}
      <div className="row">
        {atualiza ? null : (
          <div className="col-12 mt-2">
            <h3>Cadastro de Fazendas</h3>
          </div>
        )}
      </div>
      <Formik
        className="row"
        innerRef={formikRef}
        initialValues={{
          nome: "",
          url: "",
          id: null,
        }}
        validationSchema={esquema}
        onSubmit={(values) => {
          salvar(values);
        }}
      >
        {({ errors, touched, isValid }) => (
          <Form>
            <div className="col-lg-12">
              <div className="bs-component">
                <div className="row">
                  <div className="col-md-6">
                    <FormGroup
                      label="Nome:"
                      htmlFor="inputTipoDeProcedimento"
                    > <span className="text-danger font-weight-bold">*</span>
                      <Field
                        type="text"
                        placeholder="digite o nome da fazenda"
                        className={`form-control ${
                          errors.nome && touched.nome ? "invalid" : ""
                        }`}
                        name="nome"
                      />
                      {errors.nome && touched.nome ? (
                        <span className="text-error">{errors.nome}</span>
                      ) : null}
                    </FormGroup>
                  </div>
                  <div className="col-lg-6">
                    <FormGroup label="URL:" htmlFor="inputurl"><span className="text-danger font-weight-bold"> *</span>
                      <Field
                        type="text"
                        placeholder="digite a URL da fazenda"
                        className={`form-control ${
                          errors.url && touched.url ? "invalid" : ""
                        }`}
                        name="url"
                      />
                      {errors.url && touched.url ? (
                        <span className="text-error">{errors.url}</span>
                      ) : null}
                    </FormGroup>
                  </div>
                  <p><span className="text-danger font-weight-bold">*</span> Campos obrigatórios</p>
                </div>

                <button
                  type="submit"
                  onClick={() => {
                    if (!isValid) {
                      Alert.warning("Preencha todos os campos destacados");
                    }
                  }}
                  className={`btn ${classBtn} mb-3 mr-3`}
                >
                  <i className="fa fa-save"></i>{" "}
                  {classBtn === "btn-success" ? "Salvar" : "Editar"}
                </button>
                <button type="reset" className="btn btn-danger mb-3">
                  <i className="fa fa-times"></i> Cancelar
                </button>
              </div>
            </div>
          </Form>
        )}
      </Formik>
      <section className="row">
        <table className="table table-striped table-bordered table-hover">
          <thead className="thead-dark">
            <tr>
              <th scope="col">#</th>
              <th scope="col">Nome</th>
              <th scope="col">URL</th>
              <th scope="col">Ações</th>
            </tr>
          </thead>
          <tbody>
            {fazendas.map((feed, index) => {
              return (
                <tr>
                  <th scope="row">{index + 1}</th>
                  <td>{feed.nome}</td>
                  <td>{feed.url}</td>
                  <td>
                    <div>
                        <button className="btn btn-warning m-1"
                        onClick={(e) => editarFazenda(feed)}>
                          <i className="fa fa-pencil" />
                          <span className="ml-2">Editar</span>
                        </button>
                        <button className="btn btn-danger m-1" 
                        onClick={() => {
                          setAtivo(true);
                          setId(feed.id);
                          setNome(feed.nome);
                        }}>
                          <i className="fa fa-trash" />
                          <span className="ml-2">Excluir</span>
                        </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>
    </div>
  );
};

export default Fazenda;
