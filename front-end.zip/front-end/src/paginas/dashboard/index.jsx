import React, { useState, useEffect } from "react";
import celsius from "../../imagens/celsius.png";
// import fahrenheit from "./imagens/graus-fahrenheit.png";
import aviso from "../../imagens/aviso.png";
import axios from "axios";
import AppFooter from "../../componentes/AppFooter";
import "../../App.css";

const api = axios.create({
  baseURL: "http://localhost:8080",
});

function App() {
  const [dados, setDados] = useState({ channel: {}, feeds: [{}] });

  const formatDate = (dateString) => {
    const options = {
      year: "numeric",
      month: "numeric", //numeric
      day: "numeric",
      hour: "numeric",
      minute: "numeric",
    };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  function formatDecimal(numero) {
    const numeroFormat = parseFloat(numero).toFixed(2);
    return numeroFormat;
  }

  useEffect(() => {
    api.get(`/sensores`).then(({ data }) => {
      //console.log(data);
      setDados(data);
    });
  }, []);
  return (
    <div className="App">
      <div className="container mt-2">

        <section className="row mt-3 justify-content-center">
          <h3 className="col-md-12">Temperaturas</h3>
          {/* BOTÃO ATUALIZAR LISTAGEM */}
          <div className="col-md-3">
            <div class="card bg-light mb-3">
              <div class="card-header">Da massa</div>
              <div class="card-body">
                {/* <h4 class="card-title"></h4> */}
                <div class="text-center">
                  {" "}
                  <h1 class="card-text">
                    {formatDecimal(dados.feeds[0].field2)}
                    <img
                      src={aviso}
                      className="img-fluid fa-pulse"
                      alt="logo"
                    />
                  </h1>
                </div>
              </div>
              <div className="card-footer">
                {/* <p className="text-muted">
                  Data: */}
                <h5 className="text-muted">{dados.feeds[0].created_at}</h5>
                {/* </p> */}
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div class="card bg-light mb-3">
              <div class="card-header">Da saída de ar</div>
              <div class="card-body">
                {/* <h4 class="card-title"></h4> */}
                <div class="text-center">
                  {" "}
                  <h1 class="card-text">
                    {formatDecimal(dados.feeds[0].field1)}{" "}
                    <img src={celsius} className="img-fluid" alt="logo" />
                  </h1>
                </div>
              </div>
              <div className="card-footer">
                <h5 className="text-muted">{dados.feeds[0].created_at}</h5>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div class="card bg-light mb-3">
              <div class="card-header">Ambiente</div>
              <div class="card-body">
                {/* <h4 class="card-title"></h4> */}
                <div class="text-center">
                  {" "}
                  <h1 class="card-text">
                    {formatDecimal(dados.feeds[0].field3)}
                    <img src={celsius} className="img-fluid" alt="logo" />
                  </h1>
                </div>
              </div>
              <div className="card-footer">
                <h5 className="text-muted">{dados.feeds[0].created_at}</h5>
              </div>
            </div>
          </div>
          <div className="col-md-3">
            <div class="card bg-light mb-3">
              <div class="card-header">Da umidade do ambiente</div>
              <div class="card-body">
                {/* <h4 class="card-title"></h4> */}
                <div class="text-center">
                  {" "}
                  <h1 class="card-text">
                    {formatDecimal(dados.feeds[0].field4)}{" "}
                    <img src={celsius} className="img-fluid" alt="logo" />
                  </h1>
                </div>
              </div>
              <div className="card-footer">
                <h5 className="text-muted">{dados.feeds[0].created_at}</h5>
              </div>
            </div>
          </div>
        </section>
        <section className="row">
          <table className="table table-striped table-bordered table-hover">
            <thead className="thead-dark">
              <tr>
                <th scope="col">#</th>
                <th scope="col">Massa</th>
                <th scope="col">Saída do ar</th>
                <th scope="col">Ambiente</th>
                <th scope="col">Umidade do ambiente</th>
                <th scope="col">Corrente</th>
                <th scope="col">Data / Hora</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {dados.feeds.map((feed, index) => (
                <tr>
                  <th scope="row">{index + 1}</th>
                  <td>{feed.field2}</td>
                  <td>{formatDecimal(feed.field1)}</td>
                  <td>{formatDecimal(feed.field3)}</td>
                  <td>{formatDecimal(feed.field4)}</td>
                  <td>{formatDecimal(feed.field5)}</td>
                  <td>{formatDate(feed.created_at)}</td>
                  <td>
                    <span
                      className={`fa ${
                        feed.field1 > 1 && feed.field2 > 2
                          ? "fa-check-square-o"
                          : "fa-times-circle-o"
                      }`}
                    ></span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      </div>
      <AppFooter></AppFooter>
    </div>
  );
}

export default App;
